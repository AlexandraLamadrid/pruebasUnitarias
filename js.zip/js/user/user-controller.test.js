const UserController = require("./user-controller");
const User = require("./user");

let userController;

beforeEach(() => {
  userController = new UserController();
});

test('add() agrega un usuario nuevo', () => {    
  const user = new User(1, "Santiago", "santiago@generation.org");
  userController.add(user);    
  expect(userController.getUsers()).toContain(user);
});

test('remove() no falla si el usuario no está en la lista', () => {
  const user = new User(2, "Laura", "laura@generation.org");
  const userNoAgregado = new User(3, "Carlos", "carlos@generation.org");

  userController.add(user);
  userController.remove(userNoAgregado); 

  expect(userController.getUsers()).toContain(user);

  expect(userController.getUsers()).not.toContain(userNoAgregado);
});

test('findByEmail() devuelve el usuario correcto si existe', () => {
  const user = new User(4, "Ana", "ana@generation.org");
  userController.add(user);

  const result = userController.findByEmail("ana@generation.org");
  expect(result).toEqual(user);
});

test('findByEmail() devuelve undefined si no encuentra', () => {
  const result = userController.findByEmail("missing@generation.org");
  expect(result).toBeUndefined();
});

test('findById() devuelve el usuario correcto si existe', () => {
  const user = new User(5, "Pedro", "pedro@generation.org");
  userController.add(user);

  const result = userController.findById(5);
  expect(result).toEqual(user);
});

test('findById() devuelve undefined si no encuentra', () => {
  const result = userController.findById(9999);
  expect(result).toBeUndefined();
});
